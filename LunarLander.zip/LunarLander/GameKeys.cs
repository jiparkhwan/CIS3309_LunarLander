﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LunarLander
{
    enum GameKeys
    {
        Up,
        Down,
        Left,
        Right,
        Space,
        Unknown
    }
}